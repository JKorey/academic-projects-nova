package ch02.apps;
import ch02.stacks.*;

public class StackDriver 
{
  public static void main(String[] args)
  {
    StackInterface<String> test;
    test = new ArrayBoundedStack01<String>();    
  }
}