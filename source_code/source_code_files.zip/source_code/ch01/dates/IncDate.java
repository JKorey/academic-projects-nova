package ch01.dates;

public class IncDate extends Date
{

  public IncDate(int newMonth, int newDay, int newYear)
  {
    super(newMonth, newDay, newYear);
  }

  public void increment()
  // Increments this IncDate to represent the next day.
  {
    // increment algorithm goes here
  }
}
 